package tachiyomi.core.common

object Constants {
    const val URL_HELP = "https://mihon.app/docs/guides/troubleshooting/"
    const val URL_HELP_UPCOMING = "https://mihon.app/docs/faq/updates/upcoming"
    const val URL_DONATE_PATREON = "https://patreon.com/mihon/membership"
    const val URL_DONATE_OPENCOLLECTIVE = "https://opencollective.com/mihon/contribute"
    const val URL_DISCORD = "https://discord.gg/mihon"

    const val MANGA_EXTRA = "manga"

    const val MAIN_ACTIVITY = "eu.kanade.tachiyomi.ui.main.MainActivity"

    // Shortcut actions
    const val SHORTCUT_LIBRARY = "eu.kanade.tachiyomi.SHOW_LIBRARY"
    const val SHORTCUT_MANGA = "eu.kanade.tachiyomi.SHOW_MANGA"
    const val SHORTCUT_UPDATES = "eu.kanade.tachiyomi.SHOW_RECENTLY_UPDATED"
    const val SHORTCUT_HISTORY = "eu.kanade.tachiyomi.SHOW_RECENTLY_READ"
    const val SHORTCUT_SOURCES = "eu.kanade.tachiyomi.SHOW_CATALOGUES"
    const val SHORTCUT_EXTENSIONS = "eu.kanade.tachiyomi.EXTENSIONS"
    const val SHORTCUT_DOWNLOADS = "eu.kanade.tachiyomi.SHOW_DOWNLOADS"
}
