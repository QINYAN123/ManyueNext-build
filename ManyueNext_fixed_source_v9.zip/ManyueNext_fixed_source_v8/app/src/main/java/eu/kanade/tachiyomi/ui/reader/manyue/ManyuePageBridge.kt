package eu.kanade.tachiyomi.ui.reader.manyue

import android.content.Context
import android.graphics.Bitmap
import eu.kanade.tachiyomi.ui.reader.viewer.ReaderPageImageView
import java.io.ByteArrayOutputStream
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import logcat.LogPriority
import okio.Buffer
import tachiyomi.core.common.util.system.logcat

/**
 * Per-page bridge between the async AI scheduler and a ReaderPageImageView.
 *
 * - Captures the identity (mangaId/chapterId/pageIndex) at start.
 * - On AI completion, verifies identity still matches before refreshing.
 * - Stitches cached WebP segments into one Bitmap, optionally runs classic enhancement.
 * - All callbacks arrive on the main thread (ManyueAiUpscaler posts to main looper).
 */
class ManyuePageBridge(
    private val view: ReaderPageImageView,
    private val config: ReaderPageImageView.Config,
) {
    data class Identity(val mangaId: Long, val chapterId: Long, val pageIndex: Int)

    @Volatile
    private var identity: Identity? = null
    private var token: String? = null
    private var listener: ManyueAiUpscaler.OnAiCompleteListener? = null
    private var startJob: Job? = null
    private var renderJob: Job? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    /**
     * Kick off an AI upscale for [identity] using [originalBytes] (the un-classic source).
     * No-op when mode is OFF/CLASSIC, device unsupported, animated, or AI would not increase width.
     */
    fun tryStartAi(
        context: Context,
        identity: Identity,
        originalBytes: ByteArray,
        onEnhancedDimensions: (Int, Int) -> Unit,
        onState: (ManyueEnhancementState, String?) -> Unit,
    ) {
        cancel()
        val mode = ManyueRuntimeState.modeInt
        if (mode != ManyueEnhancementMode.AI_2X.value &&
            mode != ManyueEnhancementMode.AI_2X_CLASSIC.value
        ) return
        val expectedGeneration = ManyueRuntimeState.generation
        this.identity = identity
        onState(ManyueEnhancementState.AI_QUEUED, null)
        startJob = scope.launch {
            val t = withContext(Dispatchers.IO) {
                ManyueAiRequestFactory.enqueue(
                    context = context,
                    identity = identity,
                    originalBytes = originalBytes,
                    priority = 100,
                    expectedMode = mode,
                    generation = expectedGeneration,
                )
            } ?: run {
                val capability = withContext(Dispatchers.IO) { ManyueAiRuntime.probe(context) }
                val detail = if (capability == ManyueAiRuntime.Capability.READY) {
                    "图片格式、尺寸或目标宽度不适用"
                } else {
                    capability.userMessage
                }
                onState(ManyueEnhancementState.SKIPPED, detail)
                return@launch
            }
            if (!isCurrentBeforeToken(identity, mode, expectedGeneration)) {
                ManyueAiUpscaler.cancel(t)
                return@launch
            }
            token = t

            val strength = ManyueRuntimeState.classicStrength
            val wantClassic = (mode == ManyueEnhancementMode.AI_2X_CLASSIC.value)
            val completionListener = ManyueAiUpscaler.OnAiCompleteListener { tok, state, detail ->
                if (!isCurrent(t, identity, mode, expectedGeneration)) return@OnAiCompleteListener
                if (state != ManyueAiUpscaler.STATE_READY) {
                    onState(
                        ManyueEnhancementState.FAILED,
                        detail ?: "AI 推理失败，已保留原图",
                    )
                    return@OnAiCompleteListener
                }
                renderJob?.cancel()
                renderJob = scope.launch {
                    try {
                        val rendered = withContext(Dispatchers.Default) {
                            buildRenderedResult(context, tok, wantClassic, strength)
                        } ?: run {
                            onState(ManyueEnhancementState.FAILED, "AI 结果读取失败")
                            return@launch
                        }
                        if (!isCurrent(t, identity, mode, expectedGeneration)) return@launch
                        view.setImage(Buffer().write(rendered.bytes), false, config)
                        onEnhancedDimensions(rendered.width, rendered.height)
                        onState(rendered.state, rendered.detail)
                        logcat {
                            "Manyue reader replace chapter=${identity.chapterId} " +
                                "page=${identity.pageIndex} token=$t"
                        }
                    } catch (_: CancellationException) {
                        // Holder was rebound or detached.
                    } catch (error: Throwable) {
                        logcat(LogPriority.WARN, error) { "Manyue AI render failed; original retained" }
                        onState(ManyueEnhancementState.FAILED, "AI 结果显示失败")
                    }
                }
            }
            listener = completionListener
            ManyueAiUpscaler.addListener(t, completionListener)
        }
    }

    private fun isCurrentBeforeToken(
        expectedIdentity: Identity,
        expectedMode: Int,
        expectedGeneration: Long,
    ): Boolean = identity == expectedIdentity &&
        ManyueRuntimeState.modeInt == expectedMode &&
        ManyueRuntimeState.generation == expectedGeneration

    private data class RenderedResult(
        val bytes: ByteArray,
        val width: Int,
        val height: Int,
        val state: ManyueEnhancementState,
        val detail: String?,
    )

    private fun buildRenderedResult(
        context: Context,
        token: String,
        wantClassic: Boolean,
        strength: Int,
    ): RenderedResult? {
        var bitmap: Bitmap? = null
        var finalBitmap: Bitmap? = null
        try {
            bitmap = ManyueAiUpscaler.loadCachedBitmap(context, token) ?: return null
            val classicSafe = !wantClassic || ManyueAiSafetyPolicy.isPixelBudgetSafe(
                bitmap.width,
                bitmap.height,
                ManyueAiSafetyPolicy.MAX_CLASSIC_PIXELS,
            )
            val output = if (wantClassic && classicSafe && strength > 0) {
                ManyueClassicEnhancer.enhance(bitmap, strength, isAiCombined = true)
            } else {
                bitmap
            }
            finalBitmap = output
            val out = ByteArrayOutputStream()
            check(output.compress(Bitmap.CompressFormat.WEBP_LOSSY, 92, out))
            val state = if (wantClassic && classicSafe && strength > 0) {
                ManyueEnhancementState.AI_CLASSIC_READY
            } else {
                ManyueEnhancementState.AI_READY
            }
            val detail = when {
                wantClassic && strength <= 0 -> "经典增强强度为 0"
                wantClassic && !classicSafe -> "经典增强超过内存限制，已保留 AI 超分"
                else -> null
            }
            return RenderedResult(out.toByteArray(), output.width, output.height, state, detail)
        } finally {
            finalBitmap?.takeIf { it !== bitmap && !it.isRecycled }?.recycle()
            bitmap?.takeIf { !it.isRecycled }?.recycle()
        }
    }

    private fun isCurrent(
        expectedToken: String,
        expectedIdentity: Identity,
        expectedMode: Int,
        expectedGeneration: Long,
    ): Boolean = ManyueAiSafetyPolicy.isCompletionCurrent(
        expectedToken = expectedToken,
        currentToken = token,
        expectedIdentity = expectedIdentity,
        currentIdentity = identity,
        expectedMode = expectedMode,
        currentMode = ManyueRuntimeState.modeInt,
        expectedGeneration = expectedGeneration,
        currentGeneration = ManyueRuntimeState.generation,
    )

    /** Cancel pending AI and drop any identity binding. Safe to call repeatedly. */
    fun cancel() {
        startJob?.cancel()
        startJob = null
        val currentToken = token
        val currentListener = listener
        if (currentToken != null && currentListener != null) {
            ManyueAiUpscaler.removeListener(currentToken, currentListener)
        }
        renderJob?.cancel()
        renderJob = null
        listener = null
        token = null
        identity = null
    }
}
