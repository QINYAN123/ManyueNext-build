package eu.kanade.tachiyomi.ui.reader.manyue

import android.content.Context
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.ui.reader.model.ReaderPage
import eu.kanade.tachiyomi.ui.reader.metadata.SourceImageBoundsDecoder
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okio.Buffer
import tachiyomi.core.common.util.system.logcat

/**
 * Explicitly creates AI work for the next five chapter pages. The visible holder creates the
 * current-page request at priority 100; this coordinator creates +1..+5 at 50/40/30/20/10.
 */
class ManyueReaderPrefetcher(context: Context) {

    private data class PageKey(val chapterId: Long, val pageIndex: Int)

    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val jobs = ConcurrentHashMap<PageKey, Job>()

    /**
     * Update the page window and start background loads. Viewers may update
     * [ManyuePrefetchManager] before the visible holder is rebound so a backward
     * swipe cannot have its just-created current request cancelled as stale.
     */
    fun onPageSelected(current: ReaderPage, managerAlreadyUpdated: Boolean = false) {
        val chapterId = current.chapter.chapter.id ?: 0L
        if (!managerAlreadyUpdated) {
            ManyuePrefetchManager.onPageChanged(chapterId, current.index)
        }
        val mode = ManyueRuntimeState.modeInt
        if (mode != ManyueEnhancementMode.AI_2X.value &&
            mode != ManyueEnhancementMode.AI_2X_CLASSIC.value
        ) {
            cancelJobs()
            return
        }

        val pages = current.chapter.pages ?: return
        val generation = ManyueRuntimeState.generation
        // Keep the current page in the desired set even though a fresh current-page load is
        // normally owned by the visible holder. This prevents an in-flight prefetch for a page
        // that just became visible from being cancelled before it can enqueue its AI request.
        val desired = ManyueAiSafetyPolicy.prefetchPlan(current.index, pages.size)
            .associateBy { PageKey(chapterId, it.pageIndex) }
        jobs.keys.filter { it !in desired }.forEach { key -> jobs.remove(key)?.cancel() }

        desired.forEach { (key, target) ->
            if (jobs.containsKey(key)) return@forEach
            // The visible holder already loads/enqueues the current page. Only preserve an
            // existing current-page job; do not start a duplicate load on a fresh selection.
            if (target.pageIndex == current.index) return@forEach
            val page = pages.getOrNull(target.pageIndex) ?: return@forEach
            val job = scope.launch {
                try {
                    val bytes = loadBytes(page) ?: return@launch
                    page.updateSourceImageInfo(SourceImageBoundsDecoder.decode(Buffer().write(bytes)))
                    if (ManyueRuntimeState.modeInt != mode || ManyueRuntimeState.generation != generation) return@launch
                    val identity = ManyuePageBridge.Identity(
                        mangaId = page.chapter.chapter.manga_id ?: 0L,
                        chapterId = chapterId,
                        pageIndex = page.index,
                    )
                    logcat { "Manyue prefetch create page=${page.index} priority=${target.priority}" }
                    withContext(Dispatchers.IO) {
                        ManyueAiRequestFactory.enqueue(
                            appContext,
                            identity,
                            bytes,
                            target.priority,
                            mode,
                            generation,
                        )
                    }
                } finally {
                    jobs.remove(key)
                }
            }
            jobs[key] = job
        }
    }

    private suspend fun loadBytes(page: ReaderPage): ByteArray? = withContext(Dispatchers.IO) {
        val loader = page.chapter.pageLoader ?: return@withContext null
        val ready = coroutineScope {
            val loadJob = launch { loader.loadPage(page) }
            try {
                withTimeoutOrNull(60_000L) {
                    page.statusFlow
                        .filter { it == Page.State.Ready || it is Page.State.Error }
                        .first()
                }
            } finally {
                loadJob.cancel()
            }
        }
        if (ready != Page.State.Ready) return@withContext null
        val stream = page.stream ?: return@withContext null
        stream().use { Buffer().readFrom(it).readByteArray() }
    }

    fun reset() {
        cancelJobs()
    }

    fun destroy() {
        cancelJobs()
        scope.cancel()
    }

    private fun cancelJobs() {
        jobs.values.forEach(Job::cancel)
        jobs.clear()
    }
}
