package eu.kanade.tachiyomi.ui.reader.manyue

import android.content.Context
import android.os.Build
import android.os.SystemClock
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.concurrent.CancellationException
import java.util.concurrent.TimeUnit
import tachiyomi.core.common.util.system.logcat

/**
 * Thin wrapper around the native libmanyue_realesr.so binary executed via ProcessBuilder.
 */
object ManyueAiRuntime {

    enum class Capability(val userMessage: String) {
        READY("原生运行库已验证"),
        UNSUPPORTED_ABI("仅支持 arm64-v8a"),
        MISSING_BINARY("AI 原生程序缺失"),
        CORRUPT_BINARY("AI 原生程序校验失败"),
        NOT_EXECUTABLE("AI 原生程序不可执行"),
    }

    const val MAX_MODEL_OUTPUT_PIXELS = 48_000_000
    const val MAX_INPUT_BYTES = 67108864 // 64 MiB
    private const val TIMEOUT_SECONDS = 240L
    private const val WAIT_SLICE_MS = 250L
    private const val LOG_TAIL_CHARS = 4096
    // Let RealSR-NCNN choose a tile size from the actual Vulkan heap. The old fixed 64px
    // tile produced hundreds of tiny dispatches on high-end devices such as Snapdragon 8 Gen 2.
    private const val TILE_SIZE_AUTO = 0
    // Keep one native process, but restore the upstream load/proc/save pipeline concurrency.
    // This improves overlap without multiplying model processes or their memory footprint.
    private const val JOBS = "1:2:2"

    class CancelledException : CancellationException("Manyue AI request cancelled")

    private const val EXPECTED_RUNNER_SHA256 = "d74e2ff5366a3b548118d78d72a4e8e197c764dfda4222a1718c10f50cdece2b"
    private const val EXPECTED_NCNN_SHA256 = "87d150e735157b09aa20f26f5e57f72468c548e7ce98ce407ec50ee7e14a52dd"

    @Volatile private var cachedProbe: Pair<String, Capability>? = null

    fun isSupported(): Boolean = Build.SUPPORTED_64_BIT_ABIS.contains("arm64-v8a")

    fun isSupported(context: Context): Boolean = probe(context) == Capability.READY

    /** Fast after the first call; verifies the exact packaged native files once per install path. */
    fun probe(context: Context): Capability {
        if (!isSupported()) return Capability.UNSUPPORTED_ABI
        val nativeDir = context.applicationInfo.nativeLibraryDir
        cachedProbe?.takeIf { it.first == nativeDir }?.let { return it.second }
        val runner = File(nativeDir, "libmanyue_realesr.so")
        val ncnn = File(nativeDir, "libncnn.so")
        val result = runCatching {
            when {
                !runner.isFile || !ncnn.isFile ||
                    runner.length() == 0L || ncnn.length() == 0L -> Capability.MISSING_BINARY
                sha256(runner) != EXPECTED_RUNNER_SHA256 ||
                    sha256(ncnn) != EXPECTED_NCNN_SHA256 -> Capability.CORRUPT_BINARY
                !runner.canExecute() &&
                    (!runner.setExecutable(true, false) || !runner.canExecute()) -> Capability.NOT_EXECUTABLE
                else -> Capability.READY
            }
        }.getOrElse {
            logcat { "Manyue capability probe failed: ${it.javaClass.simpleName}" }
            Capability.CORRUPT_BINARY
        }
        cachedProbe = nativeDir to result
        logcat { "Manyue capability=$result nativeDir=$nativeDir" }
        return result
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    /**
     * Runs the native upscaler. Throws on any failure; caller falls back to original image.
     */
    fun upscale(
        context: Context,
        inputFile: File,
        outputFile: File,
        modelDir: File,
        logFile: File,
        isCancelled: () -> Boolean = { false },
        onProcessStarted: (Process) -> Unit = {},
    ) {
        val nativeDir = context.applicationInfo.nativeLibraryDir
        val binary = File(nativeDir, "libmanyue_realesr.so")
        val ncnn = File(nativeDir, "libncnn.so")
        require(probe(context) == Capability.READY) { "AI runtime unavailable: ${probe(context)}" }
        require(inputFile.isFile && inputFile.length() > 0L) { "AI input missing or empty: $inputFile" }
        require(binary.isFile && binary.length() > 0L) { "native binary missing: $binary" }
        require(ncnn.isFile && ncnn.length() > 0L) { "libncnn missing: $ncnn" }
        if (!binary.canExecute() && (!binary.setExecutable(true, false) || !binary.canExecute())) {
            error("native binary is not executable: $binary")
        }
        if (!File(modelDir, "x2.bin").isFile || !File(modelDir, "x2.param").isFile) {
            error("model files missing in $modelDir")
        }
        outputFile.delete()
        logFile.parentFile?.mkdirs()
        logFile.delete()

        val pb = ProcessBuilder(
            binary.absolutePath,
            "-i", inputFile.absolutePath,
            "-o", outputFile.absolutePath,
            "-s", "2",
            "-t", TILE_SIZE_AUTO.toString(),
            "-m", modelDir.absolutePath,
            "-j", JOBS,
            "-f", "webp",
            "-v",
        )
        pb.directory(File(nativeDir))
        pb.environment()["LD_LIBRARY_PATH"] = nativeDir
        pb.redirectErrorStream(true)
        // Always drain native stdout/stderr to a file. An unread Process pipe can fill and
        // deadlock waitFor() on real devices even though JVM unit tests stay green.
        pb.redirectOutput(logFile)

        val startedAt = SystemClock.elapsedRealtime()
        logcat {
            "Manyue native start binary=${binary.absolutePath} inputBytes=${inputFile.length()} " +
                "tile=auto jobs=$JOBS verbose=true LD_LIBRARY_PATH=$nativeDir"
        }
        val process = pb.start()
        logcat { "Manyue native process started" }
        onProcessStarted(process)
        val deadline = SystemClock.elapsedRealtime() + TimeUnit.SECONDS.toMillis(TIMEOUT_SECONDS)
        try {
            while (!process.waitFor(WAIT_SLICE_MS, TimeUnit.MILLISECONDS)) {
                if (isCancelled()) {
                    stop(process)
                    throw CancelledException()
                }
                if (SystemClock.elapsedRealtime() >= deadline) {
                    stop(process)
                    throw RuntimeException(
                        "AI upscaler timeout after ${TIMEOUT_SECONDS}s; ${logTail(logFile)}",
                    )
                }
            }
        } catch (t: InterruptedException) {
            stop(process)
            Thread.currentThread().interrupt()
            throw CancelledException()
        }
        if (isCancelled()) throw CancelledException()
        val code = process.exitValue()
        if (code != 0) {
            throw RuntimeException("AI upscaler exit code=$code; ${logTail(logFile)}")
        }
        if (!outputFile.exists() || outputFile.length() == 0L) {
            throw RuntimeException("AI upscaler produced no output; ${logTail(logFile)}")
        }
        val elapsedMs = SystemClock.elapsedRealtime() - startedAt
        val telemetry = runtimeTelemetry(logFile)
        logcat {
            "Manyue native exit code=0 outputBytes=${outputFile.length()} durationMs=$elapsedMs " +
                telemetry
        }
    }

    private fun stop(process: Process) {
        runCatching { process.destroy() }
        runCatching {
            if (!process.waitFor(2, TimeUnit.SECONDS)) process.destroyForcibly()
        }
        runCatching { process.waitFor(2, TimeUnit.SECONDS) }
    }

    fun readLogTail(file: File): String {
        val text = runCatching { file.readText() }.getOrDefault("")
            .takeLast(LOG_TAIL_CHARS)
            .replace('\n', ' ')
            .trim()
        return text.takeIf(String::isNotBlank)?.let { "nativeLog=$it" }.orEmpty()
    }

    /** Keep the useful device/tile line visible without copying the whole native log to UI. */
    private fun runtimeTelemetry(file: File): String {
        val line = runCatching {
            file.useLines { lines ->
                lines.firstOrNull {
                    it.contains("Gpu[") ||
                        it.contains("init gpu tilesize") ||
                        it.contains("init cpu tilesize")
                }
            }
        }.getOrNull()?.trim()?.takeIf(String::isNotEmpty) ?: return ""
        return "telemetry=${line.take(320)}"
    }

    private fun logTail(file: File): String = readLogTail(file)
}
