package eu.kanade.tachiyomi.ui.reader.manyue

import android.content.Context
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest

/**
 * Disk cache for AI-enhanced image bundles.
 * Layout: <cacheDir>/manyue_ai_anime_dynamic_v3/<key>/{manifest.json,part_0.webp,...}
 */
object ManyueEnhancementCache {

    const val MODEL_VERSION = "anime_dynamic_v3"
    private const val CACHE_DIR_NAME = "manyue_ai_anime_dynamic_v3"

    private const val MAX_CACHE_BYTES = 805_306_368L // 768 MiB
    private const val TRIM_TO_BYTES = 671_088_640L // 640 MiB

    fun cacheDir(context: Context): File =
        File(context.cacheDir, CACHE_DIR_NAME).apply { mkdirs() }

    fun cacheKey(
        mangaId: Long,
        chapterId: Long,
        pageIndex: Int,
        mode: Int,
        targetMode: Int,
        targetWidth: Int,
        classicStrength: Int,
        sourceFingerprint: String = "",
    ): String {
        val raw = "$MODEL_VERSION|$mangaId|$chapterId|$pageIndex|$mode|$targetMode|$targetWidth|$classicStrength|$sourceFingerprint|v4"
        val md = MessageDigest.getInstance("MD5").digest(raw.toByteArray())
        return md.joinToString("") { "%02x".format(it) }
    }

    /** Returns the bundle dir if manifest + all parts exist, else null. */
    fun getBundle(context: Context, key: String): File? {
        val dir = File(cacheDir(context), key)
        if (!dir.isDirectory) return null
        val manifest = File(dir, "manifest.json")
        if (!manifest.exists() || manifest.length() == 0L) return null
        val expectedParts = runCatching {
            Regex("\\\"parts\\\"\\s*:\\s*(\\d+)")
                .find(manifest.readText())
                ?.groupValues
                ?.get(1)
                ?.toInt()
        }.getOrNull() ?: return null
        if (expectedParts <= 0) return null
        val parts = dir.listFiles { f -> f.name.startsWith("part_") && f.name.endsWith(".webp") }
        if (parts.isNullOrEmpty()) return null
        if (parts.size != expectedParts) return null
        val expectedNames = (0 until expectedParts).mapTo(hashSetOf()) { "part_$it.webp" }
        if (parts.mapTo(hashSetOf()) { it.name } != expectedNames) return null
        if (parts.any { it.length() == 0L }) return null
        dir.setLastModified(System.currentTimeMillis())
        return dir
    }

    /** Atomically write a bundle: stage into .pending then rename. */
    fun putBundle(context: Context, key: String, parts: List<File>, manifestJson: String = defaultManifest(parts)) {
        val base = cacheDir(context)
        val finalDir = File(base, key)
        val pending = File(base, "$key.pending")
        if (pending.exists()) pending.deleteRecursively()
        pending.mkdirs()

        parts.forEachIndexed { i, src ->
            FileOutputStream(File(pending, "part_$i.webp")).use { out ->
                FileInputStream(src).use { it.copyTo(out) }
            }
        }
        File(pending, "manifest.json").writeText(manifestJson)

        if (finalDir.exists()) finalDir.deleteRecursively()
        if (!pending.renameTo(finalDir)) {
            pending.deleteRecursively()
            error("failed to commit cache bundle $key")
        }
    }

    private fun defaultManifest(parts: List<File>): String {
        return buildJsonObject(
            "parts" to parts.size,
            "bytes" to parts.sumOf { it.length() },
        )
    }

    internal fun buildJsonObject(vararg pairs: Pair<String, Any>): String {
        val sb = StringBuilder("{")
        pairs.forEachIndexed { i, (k, v) ->
            if (i > 0) sb.append(',')
            sb.append('"').append(k).append("\":")
            when (v) {
                is String -> sb.append('"').append(v).append('"')
                else -> sb.append(v.toString())
            }
        }
        sb.append('}')
        return sb.toString()
    }

    fun clearCache(context: Context) {
        cacheDir(context).deleteRecursively()
    }

    fun cacheSizeBytes(context: Context): Long {
        val dir = cacheDir(context)
        if (!dir.exists()) return 0L
        return dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }

    fun cacheSizeText(context: Context): String {
        val bytes = cacheSizeBytes(context)
        val mb = bytes / (1024.0 * 1024.0)
        return String.format("%.1f MiB", mb)
    }

    /** LRU trim to TRIM_TO_BYTES when over MAX_CACHE_BYTES. */
    fun trimCache(context: Context) {
        val dir = cacheDir(context)
        if (!dir.isDirectory) return
        var size = cacheSizeBytes(context)
        if (size <= MAX_CACHE_BYTES) return
        val entries = dir.listFiles()
            ?.filter { it.isDirectory }
            ?.sortedBy { it.lastModified() }
            ?: return
        for (e in entries) {
            if (size <= TRIM_TO_BYTES) break
            size -= e.walkTopDown().filter { it.isFile }.sumOf { it.length() }
            e.deleteRecursively()
        }
    }
}
