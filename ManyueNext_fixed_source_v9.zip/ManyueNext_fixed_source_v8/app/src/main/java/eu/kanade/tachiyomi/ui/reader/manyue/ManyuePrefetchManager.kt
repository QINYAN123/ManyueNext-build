package eu.kanade.tachiyomi.ui.reader.manyue

/**
 * Tracks per-page AI tokens and adjusts priorities when the current page changes.
 *
 * Priority scheme:
 *   current        = 100
 *   current + 1    = 50
 *   current + 2    = 40
 *   current + 3    = 30
 *   current + 4    = 20
 *   current + 5    = 10
 *   beyond +5      -> cancelled if not started
 *
 * PagerPageHolder / WebtoonPageHolder call [register] after starting an AI job.
 * The viewer calls [onPageChanged] when the visible page changes.
 */
object ManyuePrefetchManager {

    private const val WINDOW = ManyueAiSafetyPolicy.PREFETCH_AHEAD

    private data class PageKey(val chapterId: Long, val pageIndex: Int)

    private val tokens = java.util.concurrent.ConcurrentHashMap<PageKey, MutableSet<String>>()
    @Volatile private var currentChapterId: Long = Long.MIN_VALUE
    @Volatile private var currentPage: Int = -1

    fun reset() {
        synchronized(this) {
            tokens.values.flatten().forEach { ManyueAiUpscaler.cancel(it) }
            tokens.clear()
            currentChapterId = Long.MIN_VALUE
            currentPage = -1
        }
    }

    /** Compatibility entry for JVM tests and callers that do not yet have a chapter id. */
    fun register(pageIndex: Int, token: String) {
        register(currentChapterId, pageIndex, token)
    }

    fun register(chapterId: Long, pageIndex: Int, token: String) {
        synchronized(this) {
            val key = PageKey(chapterId, pageIndex)
            tokens.getOrPut(key) { linkedSetOf() }.add(token)
            applyPriorities()
        }
    }

    /** Compatibility entry for tests. */
    fun onPageChanged(current: Int) {
        onPageChanged(currentChapterId, current)
    }

    fun onPageChanged(chapterId: Long, current: Int) {
        synchronized(this) {
            if (currentChapterId != Long.MIN_VALUE && currentChapterId != chapterId) {
                tokens.values.flatten().forEach { ManyueAiUpscaler.cancel(it) }
                tokens.clear()
            }
            currentChapterId = chapterId
            currentPage = current
            applyPriorities()
        }
    }

    private fun applyPriorities() {
        if (currentPage < 0) return
        val priorityFor = { idx: Int ->
            when (val d = idx - currentPage) {
                0 -> 100
                1 -> 50
                2 -> 40
                3 -> 30
                4 -> 20
                5 -> 10
                else -> Int.MAX_VALUE
            }
        }
        val it = tokens.entries.iterator()
        while (it.hasNext()) {
            val (key, pageTokens) = it.next()
            val idx = key.pageIndex
            val d = idx - currentPage
            if (key.chapterId != currentChapterId || d < 0 || d > WINDOW) {
                pageTokens.forEach(ManyueAiUpscaler::cancel)
                tokens.remove(key, pageTokens)
            } else {
                pageTokens.forEach { token -> ManyueAiUpscaler.updatePriority(token, priorityFor(idx)) }
            }
        }
    }
}
