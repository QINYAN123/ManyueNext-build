package eu.kanade.tachiyomi.ui.reader.manyue

/** Pure scheduling and memory guards shared by Pager, Webtoon, and the native worker. */
object ManyueAiSafetyPolicy {

    const val MAX_DISPLAY_PIXELS = 12_000_000
    const val MAX_CLASSIC_PIXELS = 6_000_000

    data class PrefetchTarget(val pageIndex: Int, val priority: Int)

    fun priorityFor(pageIndex: Int, currentIndex: Int): Int? = when (pageIndex - currentIndex) {
        0 -> 100
        1 -> 50
        2 -> 40
        3 -> 30
        4 -> 20
        5 -> 10
        else -> null
    }

    fun prefetchPlan(currentIndex: Int, pageCount: Int): List<PrefetchTarget> {
        if (currentIndex < 0 || pageCount <= 0 || currentIndex >= pageCount) return emptyList()
        val last = minOf(pageCount - 1, currentIndex + 5)
        return (currentIndex..last).map { index ->
            PrefetchTarget(index, requireNotNull(priorityFor(index, currentIndex)))
        }
    }

    fun isPixelBudgetSafe(width: Int, height: Int, maxPixels: Int): Boolean {
        if (width <= 0 || height <= 0 || maxPixels <= 0) return false
        return width.toLong() * height.toLong() <= maxPixels.toLong()
    }

    fun isPredictedNativeOutputSafe(sourceWidth: Int, sourceHeight: Int, maxPixels: Int): Boolean {
        if (sourceWidth <= 0 || sourceHeight <= 0) return false
        return isPixelBudgetSafe(
            width = sourceWidth.toLong().times(2).coerceAtMost(Int.MAX_VALUE.toLong()).toInt(),
            height = sourceHeight.toLong().times(2).coerceAtMost(Int.MAX_VALUE.toLong()).toInt(),
            maxPixels = maxPixels,
        )
    }

    fun isCompletionCurrent(
        expectedToken: String,
        currentToken: String?,
        expectedIdentity: Any,
        currentIdentity: Any?,
        expectedMode: Int,
        currentMode: Int,
        expectedGeneration: Long,
        currentGeneration: Long,
    ): Boolean {
        val aiMode = currentMode == ManyueEnhancementMode.AI_2X.value ||
            currentMode == ManyueEnhancementMode.AI_2X_CLASSIC.value
        return aiMode &&
            currentToken == expectedToken &&
            currentIdentity == expectedIdentity &&
            currentMode == expectedMode &&
            currentGeneration == expectedGeneration
    }
}
