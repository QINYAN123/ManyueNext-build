package eu.kanade.tachiyomi.ui.reader.manyue

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import logcat.LogPriority
import okio.Buffer
import okio.BufferedSource
import tachiyomi.core.common.util.system.logcat

/**
 * Thin, defensive hook used by PagerPageHolder / WebtoonPageHolder.
 * OFF / animated / any exception -> returns the original source untouched.
 * Classic-only enhancement is applied synchronously; AI is async (caller polls).
 */
object ManyueReaderHook {

    suspend fun applyClassic(
        source: BufferedSource,
        modeInt: Int,
        strength: Int,
        onState: (ManyueEnhancementState, String?) -> Unit = { _, _ -> },
    ): BufferedSource = withContext(Dispatchers.Default) {
        try {
            if (modeInt == ManyueEnhancementMode.OFF.value) return@withContext source
            if (modeInt != ManyueEnhancementMode.CLASSIC.value) {
                // Both AI modes are async. AI+classic applies classic only to the finished AI
                // bitmap, avoiding an unnecessary full-size copy of the original first frame.
                return@withContext source
            }
            if (strength <= 0) {
                onState(ManyueEnhancementState.SKIPPED, "强度为 0")
                return@withContext source
            }
            val bytes = source.peek().readByteArray()
            if (bytes.isEmpty()) {
                onState(ManyueEnhancementState.FAILED, "图片为空")
                return@withContext source
            }
            if (ManyueImagePipeline.isAnimated(bytes)) {
                onState(ManyueEnhancementState.SKIPPED, "动态图")
                return@withContext source
            }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (!ManyueAiSafetyPolicy.isPixelBudgetSafe(
                    bounds.outWidth,
                    bounds.outHeight,
                    ManyueAiSafetyPolicy.MAX_CLASSIC_PIXELS,
                )
            ) {
                onState(ManyueEnhancementState.SKIPPED, "超过经典增强内存限制")
                return@withContext source
            }
            val bmp: Bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                ?: return@withContext source
            var enhanced: Bitmap? = null
            try {
                enhanced = ManyueClassicEnhancer.enhance(bmp, strength, isAiCombined = false)
                val out = java.io.ByteArrayOutputStream()
                check(enhanced.compress(Bitmap.CompressFormat.WEBP_LOSSY, 92, out))
                Buffer().write(out.toByteArray()).also {
                    onState(ManyueEnhancementState.CLASSIC_READY, null)
                }
            } finally {
                enhanced?.takeIf { it !== bmp && !it.isRecycled }?.recycle()
                if (!bmp.isRecycled) bmp.recycle()
            }
        } catch (t: Throwable) {
            logcat(LogPriority.WARN, t) { "Manyue classic enhancement failed; original retained" }
            onState(ManyueEnhancementState.FAILED, "经典增强处理错误")
            source
        }
    }
}
