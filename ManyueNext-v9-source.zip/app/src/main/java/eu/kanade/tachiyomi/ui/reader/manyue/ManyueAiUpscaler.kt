package eu.kanade.tachiyomi.ui.reader.manyue

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.PriorityBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import logcat.LogPriority
import tachiyomi.core.common.util.system.logcat

/**
 * AI upscaling scheduler. Single-thread priority queue.
 * Process() is asynchronous: register -> queue -> listeners notified on main thread.
 */
object ManyueAiUpscaler {

    /** state codes */
    const val STATE_READY = 1
    const val STATE_PROCESSING = 0
    const val STATE_FAILED = -1

    private const val SEGMENT_HEIGHT = 2048
    private const val WEBP_QUALITY = 96
    private const val FAILURE_COOLDOWN_MS = 30_000L
    private const val FAILURE_LOG_DIR = "manyue_ai_failures"
    private const val MAX_FAILURE_LOGS = 8
    private const val MAX_REQUESTS = 64
    private val MODEL_SHA256 = mapOf(
        ManyueAiModel.FAST_REAL_CUGAN to mapOf(
            "up2x-no-denoise.bin" to "7f135a712830b16678cb8247b9517308c5f3858fca9b10e1c3ad5ef6e261de0c",
            "up2x-no-denoise.param" to "91efac7489bf249f092faa3764e3a3d1d31ef290051e39f2afd2138c98ccce30",
        ),
        ManyueAiModel.QUALITY_REAL_ESRGAN to mapOf(
            "x2.bin" to "548a36f9c3f4ab8da56cd3b13badf23968bee207b396dad14d04b830e5f2ab2d",
            "x2.param" to "b88ff4f00ebf019a7fdac17fdd45a7fd3665d37509efc5baf2e4da2e24420a04",
        ),
    )

    fun interface OnAiCompleteListener {
        /** Called on the main thread after the AI job for [token] finished. [state] is STATE_READY or STATE_FAILED. */
        fun onAiComplete(token: String, state: Int, detail: String?)
    }

    data class Request(
        val token: String,
        val mangaId: Long,
        val chapterId: Long,
        val pageIndex: Int,
        val inputFile: File,
        val sourceWidth: Int,
        val sourceHeight: Int,
        val targetMode: Int,
        val targetWidth: Int,
        val targetScaleTenths: Int = 20,
        var priority: Int = 10,
        val expectedMode: Int = ManyueEnhancementMode.AI_2X.value,
        val generation: Long = 0L,
        val sourceFingerprint: String = "",
        var enqueuedAt: Long = 0L,
        var failedAt: Long = 0L,
        @Volatile var cancelled: Boolean = false,
        @Volatile var queued: Boolean = false,
        @Volatile var processing: Boolean = false,
        @Volatile var runningProcess: Process? = null,
        @Volatile var completed: Boolean = false,
        @Volatile var failureDetail: String? = null,
        val requestKey: String = "",
        val model: ManyueAiModel = ManyueAiModel.DEFAULT,
        val anime4kOverlay: Boolean = false,
    ) : Comparable<Request> {
        override fun compareTo(other: Request): Int =
            other.priority.compareTo(this.priority)

        override fun equals(other: Any?): Boolean =
            other is Request && other.token == token

        override fun hashCode(): Int = token.hashCode()
    }

    private val requests = ConcurrentHashMap<String, Request>()
    private val tokensByRequestKey = ConcurrentHashMap<String, String>()
    private val queue = PriorityBlockingQueue<Request>()
    private val listeners = ConcurrentHashMap<String, CopyOnWriteArrayList<OnAiCompleteListener>>()
    private val mainHandler: Handler by lazy { Handler(Looper.getMainLooper()) }
    private var started = false

    @Synchronized
    private fun ensureStarted() {
        if (started) return
        started = true
        thread(name = "manyue-ai-worker", isDaemon = true) {
            while (!Thread.currentThread().isInterrupted) {
                try {
                    val req = queue.poll(1, TimeUnit.SECONDS) ?: continue
                    req.queued = false
                    if (req.cancelled) {
                        req.inputFile.delete()
                        continue
                    }
                    req.processing = true
                    try {
                        process(req)
                    } finally {
                        req.processing = false
                    }
                } catch (t: Throwable) {
                    logcat(LogPriority.ERROR, t) { "Manyue AI worker survived an unexpected error" }
                    Thread.sleep(500)
                }
            }
        }
    }

    @Synchronized
    fun register(
        mangaId: Long,
        chapterId: Long,
        pageIndex: Int,
        inputFile: File,
        sourceWidth: Int,
        sourceHeight: Int,
        targetMode: Int,
        targetWidth: Int,
        priority: Int,
        expectedMode: Int = ManyueRuntimeState.modeInt,
        generation: Long = ManyueRuntimeState.generation,
        sourceFingerprint: String = "",
        targetScaleTenths: Int = 20,
        model: ManyueAiModel = ManyueRuntimeState.aiModel,
        anime4kOverlay: Boolean = ManyueRuntimeState.anime4kOverlay,
    ): String {
        val requestKey = listOf(
            mangaId, chapterId, pageIndex, targetMode, targetWidth, targetScaleTenths,
            expectedMode, generation, sourceFingerprint, model.id, anime4kOverlay,
        ).joinToString("|")
        tokensByRequestKey[requestKey]?.let { existingToken ->
            val existing = requests[existingToken]
            if (existing != null && !existing.cancelled && !existing.completed && existing.failedAt == 0L) {
                inputFile.delete()
                updatePriority(existingToken, maxOf(existing.priority, priority))
                logcat { "Manyue AI reuse chapter=$chapterId page=$pageIndex token=$existingToken" }
                return existingToken
            }
            tokensByRequestKey.remove(requestKey, existingToken)
        }
        val token = UUID.randomUUID().toString()
        val req = Request(
            token, mangaId, chapterId, pageIndex, inputFile,
            sourceWidth, sourceHeight, targetMode, targetWidth, targetScaleTenths, priority,
            expectedMode, generation, sourceFingerprint, requestKey = requestKey,
            model = model, anime4kOverlay = anime4kOverlay,
        )
        requests[token] = req
        tokensByRequestKey[requestKey] = token
        return token
    }

    fun queue(token: String) {
        val req = requests[token] ?: return
        if (req.failedAt > 0L && System.currentTimeMillis() - req.failedAt < FAILURE_COOLDOWN_MS) {
            notify(req, STATE_FAILED, req.failureDetail)
            return
        }
        if (req.cancelled || req.completed || req.queued || req.processing) return
        ensureStarted()
        req.enqueuedAt = System.currentTimeMillis()
        req.queued = true
        queue.offer(req)
    }

    /** Cancel queued or running native work. Completion still has a second stale-result guard. */
    fun cancel(token: String) {
        requests[token]?.let {
            it.cancelled = true
            it.queued = false
            runCatching { it.runningProcess?.destroy() }
            runCatching { it.runningProcess?.destroyForcibly() }
            it.inputFile.delete()
        }
        requests[token]?.requestKey?.takeIf(String::isNotEmpty)?.let { tokensByRequestKey.remove(it, token) }
        queue.removeIf { it.token == token }
        removeListener(token)
    }

    /** Find an existing request/cache entry for the same page, source, model and overlay. */
    fun findReusableToken(
        context: Context,
        mangaId: Long,
        chapterId: Long,
        pageIndex: Int,
        targetMode: Int,
        targetWidth: Int,
        expectedMode: Int,
        generation: Long,
        sourceFingerprint: String,
        targetScaleTenths: Int = 20,
        model: ManyueAiModel = ManyueRuntimeState.aiModel,
        anime4kOverlay: Boolean = ManyueRuntimeState.anime4kOverlay,
    ): String? {
        val key = listOf(
            mangaId, chapterId, pageIndex, targetMode, targetWidth, targetScaleTenths,
            expectedMode, generation, sourceFingerprint, model.id, anime4kOverlay,
        ).joinToString("|")
        val token = tokensByRequestKey[key] ?: return null
        val req = requests[token]
        if (req == null || req.cancelled || req.failedAt > 0L) {
            tokensByRequestKey.remove(key, token)
            return null
        }
        if (req.completed && cachedBundle(context, token) == null) {
            tokensByRequestKey.remove(key, token)
            return null
        }
        return token
    }

    /** Update a queued task's priority (re-offers it). No-op if already cancelled/started. */
    fun updatePriority(token: String, newPriority: Int) {
        val req = requests[token] ?: return
        if (req.cancelled || req.completed || req.processing) return
        req.priority = newPriority
        if (queue.remove(req)) queue.offer(req)
    }

    fun addListener(token: String, listener: OnAiCompleteListener) {
        val req = requests[token] ?: return
        if (req.completed) {
            val context = appContext
            val finalState = if (context != null && cachedBundle(context, token) != null) STATE_READY else STATE_FAILED
            mainHandler.post { listener.onAiComplete(token, finalState, req.failureDetail) }
            return
        }
        listeners.getOrPut(token) { CopyOnWriteArrayList() }.add(listener)
        // Close the tiny race where the worker finishes between the first check and add().
        if (req.completed && listeners[token]?.remove(listener) == true) {
            val context = appContext
            val finalState = if (context != null && cachedBundle(context, token) != null) STATE_READY else STATE_FAILED
            mainHandler.post { listener.onAiComplete(token, finalState, req.failureDetail) }
        }
    }

    fun removeListener(token: String) {
        listeners.remove(token)
    }

    fun removeListener(token: String, listener: OnAiCompleteListener) {
        listeners[token]?.let { current ->
            current.remove(listener)
            if (current.isEmpty()) listeners.remove(token, current)
        }
    }

    private fun notify(req: Request, state: Int, detail: String? = req.failureDetail) {
        val ls = listeners.remove(req.token)?.toList() ?: return
        mainHandler.post {
            ls.forEach { it.onAiComplete(req.token, state, detail) }
        }
    }

    private fun cleanupFinished() {
        if (requests.size <= MAX_REQUESTS) return
        val sorted = requests.values.filter { it.completed || it.cancelled }.sortedBy { it.enqueuedAt }
        val toRemove = sorted.take(requests.size - MAX_REQUESTS)
        toRemove.forEach {
            requests.remove(it.token)
            it.requestKey.takeIf(String::isNotEmpty)?.let { key -> tokensByRequestKey.remove(key, it.token) }
        }
    }

    fun state(context: Context, token: String): Int {
        val req = requests[token] ?: return STATE_FAILED
        val key = cacheKeyFor(req)
        if (ManyueEnhancementCache.getBundle(context, key) != null) return STATE_READY
        if (req.failedAt > 0L) return STATE_FAILED
        return STATE_PROCESSING
    }

    fun cachedBundle(context: Context, token: String): File? {
        val req = requests[token] ?: return null
        return ManyueEnhancementCache.getBundle(context, cacheKeyFor(req))
    }

    /**
     * Load and stitch cached parts into a single Bitmap. Returns null on any failure.
     */
    fun loadCachedBitmap(context: Context, token: String): Bitmap? {
        return try {
            val dir = cachedBundle(context, token) ?: return null
            val parts = dir.listFiles { f -> f.name.startsWith("part_") && f.name.endsWith(".webp") }
                ?.sortedBy { it.name.removePrefix("part_").removeSuffix(".webp").toIntOrNull() ?: Int.MAX_VALUE }
                ?: return null
            if (parts.isEmpty()) return null
            val bounds = parts.map { part ->
                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(part.absolutePath, opts)
                if (opts.outWidth <= 0 || opts.outHeight <= 0) return null
                opts.outWidth to opts.outHeight
            }
            val w = bounds.maxOf { it.first }
            val hLong = bounds.sumOf { it.second.toLong() }
            if (hLong > Int.MAX_VALUE ||
                !ManyueAiSafetyPolicy.isPixelBudgetSafe(w, hLong.toInt(), ManyueAiSafetyPolicy.MAX_DISPLAY_PIXELS)
            ) return null
            if (parts.size == 1) return BitmapFactory.decodeFile(parts[0].absolutePath)
            val h = hLong.toInt()
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(out)
            var y = 0
            parts.forEach { part ->
                val decoded = BitmapFactory.decodeFile(part.absolutePath) ?: run {
                    out.recycle()
                    return null
                }
                try {
                    canvas.drawBitmap(decoded, 0f, y.toFloat(), null)
                    y += decoded.height
                } finally {
                    decoded.recycle()
                }
            }
            out
        } catch (t: Throwable) {
            null
        }
    }

    private fun cacheKeyFor(req: Request): String =
        ManyueEnhancementCache.cacheKey(
            req.mangaId, req.chapterId, req.pageIndex,
            ManyueEnhancementMode.AI_2X.value, req.targetMode, req.targetWidth, 0,
            req.sourceFingerprint,
            req.targetScaleTenths,
            modelId = req.model.id,
            anime4kOverlay = req.anime4kOverlay,
        )

    private fun process(req: Request) {
        val context = appContext ?: run {
            req.failedAt = System.currentTimeMillis()
            return
        }
        var state = STATE_FAILED
        var outDir: File? = null
        try {
            if (!requestIsCurrent(req)) return
            val key = cacheKeyFor(req)
            if (ManyueEnhancementCache.getBundle(context, key) != null) {
                state = STATE_READY
                return
            }

            val modelDir = ensureModel(context, req.model)
            if (ManyueAiRuntime.probe(context) != ManyueAiRuntime.Capability.READY) {
                req.failedAt = System.currentTimeMillis(); return
            }
            if (req.inputFile.length() > ManyueAiRuntime.MAX_INPUT_BYTES) {
                req.failedAt = System.currentTimeMillis(); return
            }
            // The current implementation decodes the native output once before segmenting it.
            // Refuse long pages before launch when the predicted 2x bitmap exceeds the safe
            // display budget; falling back to the original is preferable to a 4K/long-image OOM.
            if (!ManyueAiSafetyPolicy.isPredictedNativeOutputSafe(
                    req.sourceWidth,
                    req.sourceHeight,
                    minOf(ManyueAiRuntime.MAX_MODEL_OUTPUT_PIXELS, ManyueAiSafetyPolicy.MAX_DISPLAY_PIXELS),
                )
            ) {
                req.failedAt = System.currentTimeMillis(); return
            }

            val resolved = fixedTargetWidth(req.sourceWidth)
            val resolvedHeight = Math.round(req.sourceHeight * (resolved.toDouble() / req.sourceWidth)).toInt()
            if (!ManyueAiSafetyPolicy.isPixelBudgetSafe(
                    resolved,
                    resolvedHeight,
                    ManyueAiSafetyPolicy.MAX_DISPLAY_PIXELS,
                )
            ) {
                req.failedAt = System.currentTimeMillis(); return
            }

            outDir = File(context.cacheDir, "manyue_work_${req.token}").apply { mkdirs() }
            val outFile = File(outDir, "upscaled.webp")
            val logFile = File(outDir, "native.log")
            val nativeStartedAt = SystemClock.elapsedRealtime()
            ManyueAiRuntime.upscale(
                context = context,
                inputFile = req.inputFile,
                outputFile = outFile,
                modelDir = modelDir,
                logFile = logFile,
                model = req.model,
                isCancelled = { req.cancelled || !requestIsCurrent(req) },
                onProcessStarted = { req.runningProcess = it },
            )
            val nativeElapsedMs = SystemClock.elapsedRealtime() - nativeStartedAt
            req.runningProcess = null
            if (!requestIsCurrent(req)) return

            if (req.anime4kOverlay) {
                val overlayFile = File(outDir, "anime4k.webp")
                val aiBounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(outFile.absolutePath, aiBounds)
                val applied = ManyueAiRuntime.applyAnime4kOverlay(
                    context = context,
                    inputFile = outFile,
                    outputFile = overlayFile,
                    logFile = logFile,
                    isCancelled = { req.cancelled || !requestIsCurrent(req) },
                )
                if (applied && overlayFile.isFile && overlayFile.length() > 0L) {
                    val overlayBounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeFile(overlayFile.absolutePath, overlayBounds)
                    if (overlayBounds.outWidth == aiBounds.outWidth &&
                        overlayBounds.outHeight == aiBounds.outHeight
                    ) {
                        runCatching {
                            overlayFile.copyTo(outFile, overwrite = true)
                            overlayFile.delete()
                        }.onFailure { logcat { "Manyue Anime4K output commit failed; keeping AI output" } }
                    } else {
                        logcat {
                            "Manyue Anime4K dimension mismatch " +
                                "ai=${aiBounds.outWidth}x${aiBounds.outHeight} " +
                                "overlay=${overlayBounds.outWidth}x${overlayBounds.outHeight}; keeping AI output"
                        }
                    }
                } else {
                    logcat { "Manyue Anime4K overlay skipped; keeping AI output" }
                }
            }

            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(outFile.absolutePath, opts)
            val outW = opts.outWidth
            val outH = opts.outHeight
            if (!ManyueAiSafetyPolicy.isPixelBudgetSafe(
                    outW,
                    outH,
                    minOf(ManyueAiRuntime.MAX_MODEL_OUTPUT_PIXELS, ManyueAiSafetyPolicy.MAX_DISPLAY_PIXELS),
                )
            ) {
                req.failedAt = System.currentTimeMillis(); return
            }
            // Native produced the requested fixed 2x output. Keep it at native dimensions; no
            // post-resize is performed, avoiding a second interpolation pass.
            val postStartedAt = SystemClock.elapsedRealtime()
            val segResult = segmentToWebp(outDir, outFile, outW, outH, outW, req.sourceWidth, req.sourceHeight)
            if (!requestIsCurrent(req)) return
            ManyueEnhancementCache.putBundle(context, key, segResult.parts, segResult.manifest)
            ManyueEnhancementCache.trimCache(context)
            val waitMs = if (req.enqueuedAt > 0L) {
                (System.currentTimeMillis() - req.enqueuedAt).coerceAtLeast(0L)
            } else {
                0L
            }
            val postElapsedMs = SystemClock.elapsedRealtime() - postStartedAt
            logcat {
                "Manyue AI timings chapter=${req.chapterId} page=${req.pageIndex} " +
                    "queueWaitMs=$waitMs nativeMs=$nativeElapsedMs postMs=$postElapsedMs"
            }
            ManyueDiagnostics.record(
                "第 ${req.pageIndex + 1} 页 AI 完成（排队 ${waitMs}ms，推理 ${nativeElapsedMs}ms，处理 ${postElapsedMs}ms）",
            )
            state = STATE_READY
        } catch (_: ManyueAiRuntime.CancelledException) {
            // Cancellation is expected during rapid paging, mode changes, and viewer teardown.
            logcat { "Manyue AI cancelled chapter=${req.chapterId} page=${req.pageIndex}" }
        } catch (t: Throwable) {
            req.failedAt = System.currentTimeMillis()
            state = STATE_FAILED
            val nativeLog = outDir?.let { File(it, "native.log") }
            val nativeDetail = nativeLog?.let { ManyueAiRuntime.readLogTail(it) }
            val fullFailure = listOfNotNull(t.message, nativeDetail?.takeIf { it.isNotBlank() })
                .joinToString("；")
            val compactFailure = fullFailure.takeLast(320).ifBlank { "未知原生错误" }
            req.failureDetail = "第 ${req.pageIndex + 1} 页 AI 失败：$compactFailure"
            preserveFailureLog(context, req, nativeLog)
            logcat(LogPriority.WARN, t) {
                "Manyue AI failed chapter=${req.chapterId} page=${req.pageIndex}; original retained"
            }
            ManyueDiagnostics.record("${req.failureDetail}；已保留原图")
        } finally {
            req.runningProcess = null
            req.queued = false
            req.completed = true
            req.inputFile.delete()
            outDir?.deleteRecursively()
            notify(req, state)
            cleanupFinished()
        }
    }

    private fun requestIsCurrent(req: Request): Boolean {
        val mode = ManyueRuntimeState.modeInt
        val aiMode = mode == ManyueEnhancementMode.AI_2X.value ||
            mode == ManyueEnhancementMode.AI_2X_CLASSIC.value
        return !req.cancelled && aiMode && mode == req.expectedMode &&
            ManyueRuntimeState.generation == req.generation
    }

    private fun preserveFailureLog(context: Context, req: Request, nativeLog: File?) {
        if (nativeLog == null || !nativeLog.isFile || nativeLog.length() == 0L) return
        runCatching {
            val dir = File(context.cacheDir, FAILURE_LOG_DIR).apply { mkdirs() }
            nativeLog.copyTo(File(dir, "${req.token}.log"), overwrite = true)
            dir.listFiles()
                ?.sortedByDescending { it.lastModified() }
                ?.drop(MAX_FAILURE_LOGS)
                ?.forEach(File::delete)
        }.onFailure { error ->
            logcat(LogPriority.WARN, error) { "Manyue AI failure log could not be preserved" }
        }
    }

    private data class SegmentResult(val parts: List<File>, val manifest: String)

    /** Decode the native 2x output and slice it into SEGMENT_HEIGHT-tall WebP pieces. */
    private fun segmentToWebp(
        workDir: File,
        src: File,
        srcW: Int,
        srcH: Int,
        @Suppress("UNUSED_PARAMETER") targetWidth: Int,
        origW: Int,
        origH: Int,
    ): SegmentResult {
        val raw = BitmapFactory.decodeFile(src.absolutePath)
            ?: return SegmentResult(listOf(src), ManyueEnhancementCache.buildJsonObject(
                "parts" to 1, "sourceWidth" to origW, "sourceHeight" to origH,
                "targetWidth" to srcW, "targetHeight" to srcH,
            ))
        // Both supported workers emit their native 2x result. Do not resample here.
        val scaled: Bitmap = raw
        val w = scaled.width
        val h = scaled.height
        val dir = File(workDir, "segments").apply { mkdirs() }
        val parts = mutableListOf<File>()
        val segHeights = mutableListOf<Int>()
        var y = 0
        var i = 0
        try {
            while (y < h) {
                val segH = minOf(SEGMENT_HEIGHT, h - y)
                val seg = Bitmap.createBitmap(scaled, 0, y, w, segH)
                try {
                    val f = File(dir, "seg_$i.webp")
                    FileOutputStream(f).use {
                        check(seg.compress(Bitmap.CompressFormat.WEBP_LOSSY, WEBP_QUALITY, it))
                    }
                    parts.add(f)
                    segHeights.add(segH)
                } finally {
                    if (seg !== scaled) seg.recycle()
                }
                y += segH
                i++
            }
        } finally {
            if (scaled !== raw) raw.recycle()
            scaled.recycle()
        }
        val manifest = ManyueEnhancementCache.buildJsonObject(
            "parts" to parts.size,
            "sourceWidth" to origW,
            "sourceHeight" to origH,
            "targetWidth" to w,
            "targetHeight" to h,
            "segmentHeight" to SEGMENT_HEIGHT,
            "segmentHeights" to segHeights.joinToString(","),
        )
        return SegmentResult(parts, manifest)
    }

    private fun ensureModel(context: Context, model: ManyueAiModel): File {
        val dir = File(context.filesDir, model.runtimeDir).apply { mkdirs() }
        MODEL_SHA256.getValue(model).forEach { (name, expectedHash) ->
            val dst = File(dir, name)
            if (!dst.isFile || sha256(dst) != expectedHash) {
                val pending = File(dir, "$name.pending")
                pending.delete()
                context.assets.open("${model.assetDir}/$name").use { input ->
                    FileOutputStream(pending).use { input.copyTo(it) }
                }
                check(sha256(pending) == expectedHash) { "model checksum mismatch: $name" }
                if (dst.exists()) dst.delete()
                check(pending.renameTo(dst)) { "failed to commit model asset: $name" }
            }
        }
        return dir
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun fingerprint(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

    /** Fixed native 2x output for both models; settings no longer change the target width. */
    fun fixedTargetWidth(sourceWidth: Int): Int =
        sourceWidth.toLong().times(ManyueAiModel.DEFAULT.scale)
            .coerceAtMost(Int.MAX_VALUE.toLong()).toInt()

    /** Kept as a source-compatible helper for older integrations. */
    fun resolveTargetWidth(
        sourceWidth: Int,
        @Suppress("UNUSED_PARAMETER") targetMode: Int,
        @Suppress("UNUSED_PARAMETER") targetWidth: Int,
        @Suppress("UNUSED_PARAMETER") targetScaleTenths: Int = 20,
    ): Int = fixedTargetWidth(sourceWidth)

    /**
     * Application context must be set once at startup (e.g. in Application.onCreate).
     */
    @Volatile
    var appContext: Context? = null
}
